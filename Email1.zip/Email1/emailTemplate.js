
    var data = {

        logo: "../RocketTutor_Logo.png",
        email_logo: "../email_logo.png",
        graduate_logo: "../graduate_logo.png",
        button: "Jetzt weiter lernen",
        buttonBR: "ANNEHMEN",
        buttonBL: "ABLEHNEN",
        title: "Deine Lehrkraft hat dir eine Einladung geschickt",
        middleTitle: "Warum solltest du die Einladung annehmen?",
        iconL: "Komaldeep Chahal",
        iconR: "komaldeep1993@gmail.com",
        list: [
            {name: "1. Du kannst deiner Lehrkraft ANONYM mitteilen, was du üben willst"},
            {name: "2. Du siehst Hausaufgaben, die deine Lehrkraft aufgibt (wichtig für di nachste Klausur)"},
            
            
        ],
        
        footer: "WICHTIG: Deine Lehrkraft sieht nur anonyme Daten der ganzen Klasse. Sie kann nicht sehen, ob du Hausaufgaben gemacht hast oder welche Wissenslücken einzelne Schüler*innen haben"
    }

    function fill_template() {
        var template = Handlebars.compile(document.querySelector("#template").innerHTML);
        var filled  = template(data);
    
    document.querySelector("#output").innerHTML = filled;
    
    }