
    var data = {

        logo: "../RocketTutor_Logo.png",
        calendar_logo: "../calendar.png",
        man_logo: "../manIcon.png",
        button: "Zur Hausaufgabe",
        title: "Deine Hausaufgabe ist bald fällig!",
        iconL: "{TEACHER_NAME}",
        iconR: "{DAY}, {DUE_DATE}",
        
        footer: "Die Hausaufgabe ist bestimmt wichtig für die nächste Klausur. Du kriegst das hin!"
    }

    function fill_template() {
        var template = Handlebars.compile(document.querySelector("#template").innerHTML);
        var filled  = template(data);
    
    document.querySelector("#output").innerHTML = filled;

    }