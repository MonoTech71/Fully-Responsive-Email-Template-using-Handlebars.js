
    var data = {

        logo: "../RocketTutor_Logo.png",
        calendar_logo: "../calendar.png",
        manIcon: "../manIcon.png",
        button: "Zur Hausaufgabe",
        title: "Du hast eine neue Hausaufgabe bekommen!",
        middleTitle: "Du kriegst das hin!",
        iconL: "{TEACHER_NAME}",
        iconR: "{DAY} {DUE_DATE}",
        footer: "WICHTIG: Deine Lehrkraft sieht nur anonyme Daten der ganzen Klasse. Sie kann nichtsehen, ob du Hausaufgaben gemacht hast oder welche Wissenslücken einzelne Schüler*innen haben"
    }

    function fill_template() {
        var template = Handlebars.compile(document.querySelector("#template").innerHTML);
        var filled  = template(data);
    
    document.querySelector("#output").innerHTML = filled;

    }