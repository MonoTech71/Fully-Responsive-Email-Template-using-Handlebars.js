
    var data = {

        logo: "../RocketTutor_Logo.png",
        email_logo: "../email_logo.png",
        man_logo: "../manIcon.png",
        button: "ZUM SYSTEM",
        title: "Einer Ihrer Schüler hat Ihre Anfrage angenommen",
        middleTitle: "Was bedeutet das?",
        iconL: "Student Name",
        iconR: "studentEmail",
        list: [
            {name: "1. Die Wissenslücken des Schülers erscheinen in Ihrer Lehrkräfteansicht"},
            {name: "2. Der oder die Schülerin sieht von Ihnen verteilte Hausaufgaben"},
            {name: "3. Sie können sehen, wie viele Schüler*innen, die Hausaufgaben bearbeiten"}   
        ],
        
        footer: "WITCHING:Auch wenn noch nicht alle Schüler*innen Ihre Einladung angenommen haben oder sogar noch nicht registriert sind, können Sie schon jetzt Hausaufgaben verteilen. Schüler*innen, die Ihre Einladung später annehmen, sehen von Ihnen verteilte Hausaufgaben automatisch."
    }

    function fill_template() {
        var template = Handlebars.compile(document.querySelector("#template").innerHTML);
        var filled  = template(data);
    
    document.querySelector("#output").innerHTML = filled;

    }