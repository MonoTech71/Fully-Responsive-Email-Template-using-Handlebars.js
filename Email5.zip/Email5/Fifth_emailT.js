
    var data = {

        logo: "../RocketTutor_Logo.png",
        button: "Jetzt lernen",
        title: "{Hi! Ussername}",
        middleTitle: "Beste Noten mit kleinstem Aufwand",
        firstimg: "../firstimg.png",
        middle: "../middle.png",
        thirdImg: "../thirdImg.png",
        textF: "Beste Noten mit kleinstem Aufwand",
        textM: "Wir finden für dich die besten Aufgaben und Erklärungen",
        textL: "KI-Tutor personalisiert alles für dich ",
    }

    function fill_template() {
        var template = Handlebars.compile(document.querySelector("#template").innerHTML);
        var filled  = template(data);
    
    document.querySelector("#output").innerHTML = filled;

    }